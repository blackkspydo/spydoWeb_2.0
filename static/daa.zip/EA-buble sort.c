#include <stdio.h>
int main()
{
        int a[100], n, i, j, temp, count = 0;
        printf("Enter number of elements: ");
        scanf("%d", &n);
        printf("Enter %d elements: ", n);
        count = count + 7;
        for (i = 0; i < n; i++)
        {
                scanf("%d", &a[i]);
                count = count + 4;
        }
        count = count + 3;
        for (i = 0; i < n; i++)
        {
                count = count + 5;
                for (j = 0; j < n - i - 1; j++)
                {
                        count = count + 4;
                        if (a[j] > a[j + 1])
                        {
                                temp = a[j];
                                a[j] = a[j + 1];
                                a[j + 1] = temp;
                                count = count + 4;
                        }
                }
        }
        printf("Elements in sorted order: ");
        count = count + 4;
        for (i = 0; i < n; i++)
        {
                count = count + 4;
                printf("%d ", a[i]);
        }
        count = count + 3;
        printf("\nTotal execution steps = %d", count);
        return 0;
}
