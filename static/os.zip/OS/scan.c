#include <stdio.h>
#include <stdlib.h>
#define SIZE 50
#define DISK_SIZE 200

void SCAN(int arr[], int head, int size) {
    int seek_count = 0;
    int distance, cur_track;
    int left[SIZE], right[SIZE];
    int left_count = 0, right_count = 0;
    
    printf("Initial position of head: %d\n", head);

    for (int i = 0; i < size; i++) {
        if (arr[i] < head)
            left[left_count++] = arr[i];
        else
            right[right_count++] = arr[i];
    }

    // Sorting left and right arrays
    for (int i = 0; i < left_count - 1; i++) {
        for (int j = 0; j < left_count - i - 1; j++) {
            if (left[j] < left[j + 1]) {
                int temp = left[j];
                left[j] = left[j + 1];
                left[j + 1] = temp;
            }
        }
    }

    for (int i = 0; i < right_count - 1; i++) {
        for (int j = 0; j < right_count - i - 1; j++) {
            if (right[j] > right[j + 1]) {
                int temp = right[j];
                right[j] = right[j + 1];
                right[j + 1] = temp;
            }
        }
    }

    // Scanning right side
    for (int i = 0; i < right_count; i++) {
        cur_track = right[i];
        printf("%d\n", cur_track);
        // Calculate absolute distance
        distance = abs(cur_track - head);
        // Increase the total count
        seek_count += distance;
        // Accessed track is now new head
        head = cur_track;
    }

    // Scanning left side
    for (int i = left_count - 1; i >= 0; i--) {
        cur_track = left[i];
        printf("%d\n", cur_track);
        // Calculate absolute distance
        distance = abs(cur_track - head);
        // Increase the total count
        seek_count += distance;
        // Accessed track is now new head
        head = cur_track;
    }

    printf("Total number of seek operations = %d\n", seek_count);
}

int main() {
    int size;
    printf("Enter the number of disk requests: ");
    scanf("%d", &size);
    if(size > SIZE) {
        printf("Number of disk requests exceeded the limit.\n");
        return 1;
    }
    int arr[SIZE];
    printf("Enter the disk requests:\n");
    for(int i = 0; i < size; i++)
        scanf("%d", &arr[i]);
    int head;
    printf("Enter the initial head position: ");
    scanf("%d", &head);
    SCAN(arr, head, size);
    return 0;
}