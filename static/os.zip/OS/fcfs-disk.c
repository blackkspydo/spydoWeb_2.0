#include <stdio.h>
#include <stdlib.h>

// Function to calculate seek time using FCFS algorithm
int calculate_seek_time_FCFS(int requests[], int n, int head_position) {
    int total_seek_time = 0;
    int current_position = head_position;
    for (int i = 0; i < n; i++) {
        total_seek_time += abs(current_position - requests[i]);
        current_position = requests[i];
    }

    return total_seek_time;
}

int main() {
    int n, head_position;
    printf("Enter the number of pending requests: ");
    scanf("%d", &n);
    int requests[n];
    
    // Taking user input for pending requests
    printf("Enter the pending requests separated by spaces: ");
    for (int i = 0; i < n; i++) {
        scanf("%d", &requests[i]);
    }
    
    printf("Enter the current head position: ");
    scanf("%d", &head_position);
    
    // Calculating seek time
    int seek_time = calculate_seek_time_FCFS(requests, n, head_position);
    printf("Total seek time using FCFS algorithm: %d\n", seek_time);
    
    return 0;
}
