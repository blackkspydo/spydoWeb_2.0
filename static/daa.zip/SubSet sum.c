#include <stdio.h>
#include <stdbool.h>

// Returns true if there is a subset
// of set[] with sum equal to given sum
bool isSubsetSum(int set[], int n, int sum)
{
        // Base Cases
        if (sum == 0)
                return true;
        if (n == 0)
                return false;

        // If last element is greater than sum,
        // then ignore it
        if (set[n - 1] > sum)
                return isSubsetSum(set, n - 1, sum);

        // Else, check if sum can be obtained by any
        // of the following:
        // (a) including the last element
        // (b) excluding the last element
        return isSubsetSum(set, n - 1, sum) || isSubsetSum(set, n - 1, sum - set[n - 1]);
}

// Driver code
int main()
{
        int n, sum;

        // Ask the user for the number of elements
        printf("Enter the number of elements in the set: ");
        scanf("%d", &n);

        int set[n];

        // Ask the user for the elements
        printf("Enter the elements of the set: ");
        for (int i = 0; i < n; i++)
        {
                scanf("%d", &set[i]);
        }

        // Ask the user for the target sum
        printf("Enter the sum: ");
        scanf("%d", &sum);

        // Check if there's a subset with the given sum
        if (isSubsetSum(set, n, sum))
                printf("Found a subset with given sum\n");
        else
                printf("No subset with given sum\n");

        return 0;
}
