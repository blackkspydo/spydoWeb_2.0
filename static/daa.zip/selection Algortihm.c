#include <stdio.h>
#include <time.h>
// Global variable to count comparison
int count = 0;
// Function to swap two elements
void swap(int *a, int *b)
{
        int temp = *a;
        *a = *b;
        *b = temp;
}
// Partition functionz
int partition(int arr[], int left, int right)
{
        // Initialize pivot to be the first element
        int pivot = arr[left];
        int i = left;
        int j = right;
        while (i < j)
        {
                count++;
                // Condition 1: find the first element greater than the pivot (from starting)
                while (arr[i] <= pivot && i <= right - 1)
                {
                        i++;
                        count++; // Increment execution steps for each comparison
                }
                // Condition 2: find the first element smaller than the pivot (from last)
                while (arr[j] > pivot && j >= left + 1)
                {
                        j--;
                        count++; // Increment execution steps for each comparison
                }
                if (i < j)
                {
                        swap(&arr[i], &arr[j]);
                        count++;
                }
        }
        swap(&arr[left], &arr[j]);
        return j;
}
// Quickselect function
int quickSelect(int arr[], int left, int right, int k)
{
        if (left <= right)
        {
                count++;
                int partitionIndex = partition(arr, left, right);

                if (partitionIndex == k)
                {
                        return arr[partitionIndex];
                        count++;
                }
                else if (partitionIndex > k)
                {
                        return quickSelect(arr, left, partitionIndex - 1, k);
                        count++;
                }
                else
                {
                        return quickSelect(arr, partitionIndex + 1, right, k);
                        count++;
                }
        }
        return -1; // This line will never be reached if k is a valid index
}
// Driver code
int main()
{
        clock_t st = clock();
        int n, k;
        printf("\nEnter the number of elements: ");
        scanf("%d", &n);
        int arr[n];
        printf("Enter the elements of the array: ");
        for (int i = 0; i < n; i++)
        {
                scanf("%d", &arr[i]);
        }
        printf("Enter the value of k: ");
        scanf("%d", &k);
        if (k < 1 || k > n)
        {
                printf("Invalid value of k\n");
                return 1;
        }
        // Calling quickSelect() to find the k-th smallest element
        int kthSmallest = quickSelect(arr, 0, n - 1, k - 1);
        // Printing the k-th smallest element
        printf("The %d smallest element is: %d\n", k, kthSmallest);
        // Calculating and printing the execution time
        clock_t et = clock();
        printf("Total comparison steps: %d\n", count);
        printf("The execution time is: %f seconds\n", (double)(et - st) / CLOCKS_PER_SEC);
        return 0;
}
