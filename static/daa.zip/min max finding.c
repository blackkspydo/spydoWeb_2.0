#include <stdio.h>
#include <time.h>

// Global variable to count comparisons
int count = 0;

// Function to find the minimum and maximum elements in an array
void findMinMax(int arr[], int n, int *min, int *max)
{
        *min = arr[0];
        *max = arr[0];

        for (int i = 1; i < n; i++)
        {

                if (arr[i] < *min)
                {
                        *min = arr[i];
                        count++;
                }
                if (arr[i] > *max)
                {
                        *max = arr[i];
                        count++;
                }
        }
}

// Driver code
int main()
{
        clock_t st = clock();
        int n;
        printf("\nEnter the number of elements: ");
        scanf("%d", &n);

        int arr[n];
        printf("Enter the elements of the array: ");
        for (int i = 0; i < n; i++)
        {
                scanf("%d", &arr[i]);
        }
        int min, max;
        // Calling findMinMax() to find the minimum and maximum elements in the array
        findMinMax(arr, n, &min, &max);

        // Printing the minimum and maximum elements
        printf("Minimum element: %d\n", min);
        printf("Maximum element: %d\n", max);

        // Calculating and printing the execution time
        printf("Total comparison steps: %d\n", count);
        clock_t et = clock();
        printf("The execution time is: %f seconds\n", (double)(et - st) / CLOCKS_PER_SEC);

        return 0;
}
