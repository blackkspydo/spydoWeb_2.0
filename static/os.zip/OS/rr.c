#include<stdio.h>

int main() {
    // Input number of processes
    int n;
    printf("Enter Total Number of Processes:");
    scanf("%d", &n);
    
    int wait_time = 0, ta_time = 0, arr_time[n], burst_time[n], temp_burst_time[n];
    int x = n;

    // Input details of processes
    for(int i = 0; i < n; i++) {
        printf("Enter Details of Process %d \n", i + 1);
        printf("Arrival Time:  ");
        scanf("%d", &arr_time[i]);
        printf("Burst Time:   ");
        scanf("%d", &burst_time[i]);
        temp_burst_time[i] = burst_time[i];
    }

    // Input time quantum
    int time_quantum;
    printf("Enter Time Quantum:");
    scanf("%d", &time_quantum);

    // Variables for total time and process execution
    int total = 0, counter = 0, i = 0;

    // Display header for process details
    printf("\nProcess ID\tBurst Time\tTurnaround Time\tWaiting Time\n");

    // Loop until all processes are executed
    while(x != 0) {
        // Execute the current process within the time quantum
        if(temp_burst_time[i] <= time_quantum && temp_burst_time[i] > 0) {
            total += temp_burst_time[i];
            temp_burst_time[i] = 0;
            counter = 1;
        } 
        // Execute part of the process within the time quantum
        else if(temp_burst_time[i] > 0) {
            temp_burst_time[i] -= time_quantum;
            total += time_quantum;
        }

        // Process completion
        if(temp_burst_time[i] == 0 && counter == 1) {
            x--; // Decrement the number of processes left
            printf("\n%d\t\t%d\t\t%d\t\t%d", i + 1, burst_time[i],
                   total - arr_time[i], total - arr_time[i] - burst_time[i]);
            wait_time += total - arr_time[i] - burst_time[i];
            ta_time += total - arr_time[i];
            counter = 0;
        }

        // Move to the next process considering circular fashion
        if(i == n - 1)
            i = 0;
        else if(arr_time[i + 1] <= total)
            i++;
        else
            i = 0;
    }
     // Calculate averages
    float average_wait_time = (float)wait_time / n;
    float average_turnaround_time = (float)ta_time / n;
    printf("\nAverage Waiting Time: %.2f", average_wait_time);
    printf("\nAverage Turnaround Time: %.2f\n", average_turnaround_time);
    return 0;
}