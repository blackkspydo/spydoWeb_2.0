#include <stdio.h>
#include <stdlib.h>
void bestFit(int blockSize[], int m, int processSize[], int n) 
{
    int allocation[n];
    // Initially no block is assigned to any process
    for (int i = 0; i < n; i++)
        allocation[i] = -1;
    for (int i = 0; i < n; i++) 
    {
        // Find the best fit block for current process
        int bestIdx = -1;
        for (int j = 0; j < m; j++)
        {
            if (blockSize[j] >= processSize[i]) {
                if (bestIdx == -1 || blockSize[bestIdx] > blockSize[j])
                    bestIdx = j;
         }
     }
        if (bestIdx != -1)
        {
            // Allocate block j to process i
            allocation[i] = bestIdx;
            // Reduce available memory in this block
            blockSize[bestIdx] -= processSize[i];
        }
   }
    printf("\nProcess No.\tProcess Size\tBlock no.\n");
    for (int i = 0; i < n; i++) 
    {
        printf(" %d\t\t%d\t\t", i + 1, processSize[i]);
        if (allocation[i] != -1)
            printf("%d", allocation[i] + 1);
        else
            printf("Not Allocated");
        printf("\n");
    }
}
int main()
 {
    int m, n;
    printf("Enter the number of blocks: ");
    scanf("%d", &m);
    printf("Enter the number of processes: ");
    scanf("%d", &n);
    int blockSize[m];
    printf("Enter the size of each block:\n");
    for (int i = 0; i < m; i++) 
    {
        printf("Block %d: ", i + 1);
        scanf("%d", &blockSize[i]);
    }

    int processSize[n];
    printf("Enter the size of each process:\n");
    for (int i = 0; i < n; i++) 
    {
        printf("Process %d: ", i + 1);
        scanf("%d", &processSize[i]);
    }
    bestFit(blockSize, m, processSize, n);
    return 0;
}