#include <stdio.h>
#include <time.h>

int count = 0;
int binarySearch(int arr[], int left, int right, int x)
{
        while (left <= right)
        {
                count++;
                int mid = left + (right - left) / 2;

                // Check if x is present at mid
                if (arr[mid] == x)
                {
                        return mid;
                        count++;
                }

                // If x greater, ignore left half
                if (arr[mid] < x)
                {
                        left = mid + 1;
                        count++;
                }
                // If x is smaller, ignore right half
                else
                {
                        right = mid - 1;
                        count++;
                }
        }

        // If we reach here, then the element was not present
        return -1;
}

int main()
{
        clock_t st = clock();
        int n, x;

        printf("Enter the number of elements in the array: ");
        scanf("%d", &n);

        int arr[n];

        printf("Enter %d elements in sorted order:\n", n);
        for (int i = 0; i < n; i++)
        {
                scanf("%d", &arr[i]);
        }

        printf("Enter the element to search: ");
        scanf("%d", &x);

        int result = binarySearch(arr, 0, n - 1, x);

        if (result == -1)
        {
                printf("Element is not present in array\n");
        }
        else
        {
                printf("Element is present at index %d\n", result);
        }

        printf("Total comparison steps: %d\n", count);
        clock_t et = clock();
        printf("The execution time is: %f seconds\n", (double)(et - st) / CLOCKS_PER_SEC);

        return 0;
}
