
#include <stdio.h>
#include <time.h>

int count = 0;
// Function to compute GCD using the Euclidean algorithm
int gcd(int a, int b)
{
        while (b != 0)
        {
                int temp = b;
                b = a % b;
                a = temp;
                count++;
        }
        return a;
}

int main()
{
        clock_t st = clock();
        int num1, num2;

        // Get input from the user
        printf("Enter two integers: ");
        scanf("%d %d", &num1, &num2);

        // Calculate and display the GCD
        printf("GCD of %d and %d is %d\n", num1, num2, gcd(num1, num2));
        printf("Total comparison steps: %d\n", count);
        clock_t et = clock();
        printf("\nThe execution time is: %f seconds\n", (double)(et - st) / CLOCKS_PER_SEC);

        return 0;
}
